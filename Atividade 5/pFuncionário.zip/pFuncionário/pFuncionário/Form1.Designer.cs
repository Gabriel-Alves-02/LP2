﻿
namespace pFuncionário
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.mskNomeFuncionário = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalárioBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAlíquotaInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAlíquotaIrpf = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalárioFamília = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoInss = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIrpf = new System.Windows.Forms.MaskedTextBox();
            this.lblNomeFuncionário = new System.Windows.Forms.Label();
            this.lblSalárioBruto = new System.Windows.Forms.Label();
            this.lblAlíquotaInss = new System.Windows.Forms.Label();
            this.lblAlíquotaIrpf = new System.Windows.Forms.Label();
            this.lblSalárioFamília = new System.Windows.Forms.Label();
            this.lblSalárioLíquido = new System.Windows.Forms.Label();
            this.lblNúmerodeFilhos = new System.Windows.Forms.Label();
            this.lblDescontoIrpf = new System.Windows.Forms.Label();
            this.lblDescontoInss = new System.Windows.Forms.Label();
            this.btmVerificaDesconto = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.lstNumeroFilhos = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // mskNomeFuncionário
            // 
            this.mskNomeFuncionário.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskNomeFuncionário.Location = new System.Drawing.Point(224, 28);
            this.mskNomeFuncionário.Name = "mskNomeFuncionário";
            this.mskNomeFuncionário.Size = new System.Drawing.Size(370, 29);
            this.mskNomeFuncionário.TabIndex = 0;
            this.mskNomeFuncionário.Validated += new System.EventHandler(this.mskNomeFuncionário_Validated);
            // 
            // mskbxSalárioBruto
            // 
            this.mskbxSalárioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalárioBruto.Location = new System.Drawing.Point(224, 72);
            this.mskbxSalárioBruto.Name = "mskbxSalárioBruto";
            this.mskbxSalárioBruto.Size = new System.Drawing.Size(100, 29);
            this.mskbxSalárioBruto.TabIndex = 1;
            this.mskbxSalárioBruto.Validated += new System.EventHandler(this.mskbxSalárioBruto_Validated);
            // 
            // mskbxAlíquotaInss
            // 
            this.mskbxAlíquotaInss.Enabled = false;
            this.mskbxAlíquotaInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxAlíquotaInss.Location = new System.Drawing.Point(224, 174);
            this.mskbxAlíquotaInss.Name = "mskbxAlíquotaInss";
            this.mskbxAlíquotaInss.Size = new System.Drawing.Size(100, 29);
            this.mskbxAlíquotaInss.TabIndex = 2;
            // 
            // mskbxAlíquotaIrpf
            // 
            this.mskbxAlíquotaIrpf.Enabled = false;
            this.mskbxAlíquotaIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxAlíquotaIrpf.Location = new System.Drawing.Point(224, 218);
            this.mskbxAlíquotaIrpf.Name = "mskbxAlíquotaIrpf";
            this.mskbxAlíquotaIrpf.Size = new System.Drawing.Size(100, 29);
            this.mskbxAlíquotaIrpf.TabIndex = 3;
            // 
            // mskbxSalárioFamília
            // 
            this.mskbxSalárioFamília.Enabled = false;
            this.mskbxSalárioFamília.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalárioFamília.Location = new System.Drawing.Point(224, 268);
            this.mskbxSalárioFamília.Name = "mskbxSalárioFamília";
            this.mskbxSalárioFamília.Size = new System.Drawing.Size(100, 29);
            this.mskbxSalárioFamília.TabIndex = 4;
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Enabled = false;
            this.mskbxSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalBruto.Location = new System.Drawing.Point(224, 324);
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(100, 29);
            this.mskbxSalBruto.TabIndex = 5;
            // 
            // mskbxDescontoInss
            // 
            this.mskbxDescontoInss.Enabled = false;
            this.mskbxDescontoInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxDescontoInss.Location = new System.Drawing.Point(564, 223);
            this.mskbxDescontoInss.Name = "mskbxDescontoInss";
            this.mskbxDescontoInss.Size = new System.Drawing.Size(100, 29);
            this.mskbxDescontoInss.TabIndex = 6;
            // 
            // mskbxDescontoIrpf
            // 
            this.mskbxDescontoIrpf.Enabled = false;
            this.mskbxDescontoIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxDescontoIrpf.Location = new System.Drawing.Point(564, 282);
            this.mskbxDescontoIrpf.Name = "mskbxDescontoIrpf";
            this.mskbxDescontoIrpf.Size = new System.Drawing.Size(100, 29);
            this.mskbxDescontoIrpf.TabIndex = 7;
            // 
            // lblNomeFuncionário
            // 
            this.lblNomeFuncionário.AutoSize = true;
            this.lblNomeFuncionário.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeFuncionário.Location = new System.Drawing.Point(26, 28);
            this.lblNomeFuncionário.Name = "lblNomeFuncionário";
            this.lblNomeFuncionário.Size = new System.Drawing.Size(192, 24);
            this.lblNomeFuncionário.TabIndex = 8;
            this.lblNomeFuncionário.Text = "Nome do funcionário:";
            // 
            // lblSalárioBruto
            // 
            this.lblSalárioBruto.AutoSize = true;
            this.lblSalárioBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalárioBruto.Location = new System.Drawing.Point(27, 77);
            this.lblSalárioBruto.Name = "lblSalárioBruto";
            this.lblSalárioBruto.Size = new System.Drawing.Size(120, 24);
            this.lblSalárioBruto.TabIndex = 9;
            this.lblSalárioBruto.Text = "Salário bruto:";
            // 
            // lblAlíquotaInss
            // 
            this.lblAlíquotaInss.AutoSize = true;
            this.lblAlíquotaInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlíquotaInss.Location = new System.Drawing.Point(26, 174);
            this.lblAlíquotaInss.Name = "lblAlíquotaInss";
            this.lblAlíquotaInss.Size = new System.Drawing.Size(130, 24);
            this.lblAlíquotaInss.TabIndex = 10;
            this.lblAlíquotaInss.Text = "Alíquota INSS:";
            // 
            // lblAlíquotaIrpf
            // 
            this.lblAlíquotaIrpf.AutoSize = true;
            this.lblAlíquotaIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAlíquotaIrpf.Location = new System.Drawing.Point(27, 223);
            this.lblAlíquotaIrpf.Name = "lblAlíquotaIrpf";
            this.lblAlíquotaIrpf.Size = new System.Drawing.Size(129, 24);
            this.lblAlíquotaIrpf.TabIndex = 11;
            this.lblAlíquotaIrpf.Text = "Alíquota IRPF:";
            // 
            // lblSalárioFamília
            // 
            this.lblSalárioFamília.AutoSize = true;
            this.lblSalárioFamília.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalárioFamília.Location = new System.Drawing.Point(27, 268);
            this.lblSalárioFamília.Name = "lblSalárioFamília";
            this.lblSalárioFamília.Size = new System.Drawing.Size(129, 24);
            this.lblSalárioFamília.TabIndex = 12;
            this.lblSalárioFamília.Text = "Salário família:";
            // 
            // lblSalárioLíquido
            // 
            this.lblSalárioLíquido.AutoSize = true;
            this.lblSalárioLíquido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalárioLíquido.Location = new System.Drawing.Point(26, 324);
            this.lblSalárioLíquido.Name = "lblSalárioLíquido";
            this.lblSalárioLíquido.Size = new System.Drawing.Size(144, 24);
            this.lblSalárioLíquido.TabIndex = 13;
            this.lblSalárioLíquido.Text = "Salário Líquido: ";
            // 
            // lblNúmerodeFilhos
            // 
            this.lblNúmerodeFilhos.AutoSize = true;
            this.lblNúmerodeFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNúmerodeFilhos.Location = new System.Drawing.Point(26, 123);
            this.lblNúmerodeFilhos.Name = "lblNúmerodeFilhos";
            this.lblNúmerodeFilhos.Size = new System.Drawing.Size(159, 24);
            this.lblNúmerodeFilhos.TabIndex = 14;
            this.lblNúmerodeFilhos.Text = "Número de filhos:";
            this.lblNúmerodeFilhos.Click += new System.EventHandler(this.lblNúmerodeFilhos_Click);
            // 
            // lblDescontoIrpf
            // 
            this.lblDescontoIrpf.AutoSize = true;
            this.lblDescontoIrpf.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIrpf.Location = new System.Drawing.Point(398, 287);
            this.lblDescontoIrpf.Name = "lblDescontoIrpf";
            this.lblDescontoIrpf.Size = new System.Drawing.Size(141, 24);
            this.lblDescontoIrpf.TabIndex = 15;
            this.lblDescontoIrpf.Text = "Desconto IRPF:";
            // 
            // lblDescontoInss
            // 
            this.lblDescontoInss.AutoSize = true;
            this.lblDescontoInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoInss.Location = new System.Drawing.Point(398, 228);
            this.lblDescontoInss.Name = "lblDescontoInss";
            this.lblDescontoInss.Size = new System.Drawing.Size(142, 24);
            this.lblDescontoInss.TabIndex = 16;
            this.lblDescontoInss.Text = "Desconto INSS:";
            // 
            // btmVerificaDesconto
            // 
            this.btmVerificaDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmVerificaDesconto.Location = new System.Drawing.Point(402, 153);
            this.btmVerificaDesconto.Name = "btmVerificaDesconto";
            this.btmVerificaDesconto.Size = new System.Drawing.Size(199, 34);
            this.btmVerificaDesconto.TabIndex = 17;
            this.btmVerificaDesconto.Text = "Verifica Desconto";
            this.btmVerificaDesconto.UseVisualStyleBackColor = true;
            this.btmVerificaDesconto.Click += new System.EventHandler(this.btmVerificaDesconto_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // lstNumeroFilhos
            // 
            this.lstNumeroFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstNumeroFilhos.FormattingEnabled = true;
            this.lstNumeroFilhos.ItemHeight = 24;
            this.lstNumeroFilhos.Location = new System.Drawing.Point(224, 123);
            this.lstNumeroFilhos.Name = "lstNumeroFilhos";
            this.lstNumeroFilhos.Size = new System.Drawing.Size(100, 28);
            this.lstNumeroFilhos.TabIndex = 18;
            this.lstNumeroFilhos.SelectedIndexChanged += new System.EventHandler(this.lstNumeroFilhos_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstNumeroFilhos);
            this.Controls.Add(this.btmVerificaDesconto);
            this.Controls.Add(this.lblDescontoInss);
            this.Controls.Add(this.lblDescontoIrpf);
            this.Controls.Add(this.lblNúmerodeFilhos);
            this.Controls.Add(this.lblSalárioLíquido);
            this.Controls.Add(this.lblSalárioFamília);
            this.Controls.Add(this.lblAlíquotaIrpf);
            this.Controls.Add(this.lblAlíquotaInss);
            this.Controls.Add(this.lblSalárioBruto);
            this.Controls.Add(this.lblNomeFuncionário);
            this.Controls.Add(this.mskbxDescontoIrpf);
            this.Controls.Add(this.mskbxDescontoInss);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.mskbxSalárioFamília);
            this.Controls.Add(this.mskbxAlíquotaIrpf);
            this.Controls.Add(this.mskbxAlíquotaInss);
            this.Controls.Add(this.mskbxSalárioBruto);
            this.Controls.Add(this.mskNomeFuncionário);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskNomeFuncionário;
        private System.Windows.Forms.MaskedTextBox mskbxSalárioBruto;
        private System.Windows.Forms.MaskedTextBox mskbxAlíquotaInss;
        private System.Windows.Forms.MaskedTextBox mskbxAlíquotaIrpf;
        private System.Windows.Forms.MaskedTextBox mskbxSalárioFamília;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoInss;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIrpf;
        private System.Windows.Forms.Label lblNomeFuncionário;
        private System.Windows.Forms.Label lblSalárioBruto;
        private System.Windows.Forms.Label lblAlíquotaInss;
        private System.Windows.Forms.Label lblAlíquotaIrpf;
        private System.Windows.Forms.Label lblSalárioFamília;
        private System.Windows.Forms.Label lblSalárioLíquido;
        private System.Windows.Forms.Label lblNúmerodeFilhos;
        private System.Windows.Forms.Label lblDescontoIrpf;
        private System.Windows.Forms.Label lblDescontoInss;
        private System.Windows.Forms.Button btmVerificaDesconto;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ListBox lstNumeroFilhos;
    }
}

