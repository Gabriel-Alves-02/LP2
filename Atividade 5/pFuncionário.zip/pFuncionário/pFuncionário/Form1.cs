﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pFuncionário
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();


            lstNumeroFilhos.Items.Add("0");
            lstNumeroFilhos.Items.Add("1");
            lstNumeroFilhos.Items.Add("2");
            lstNumeroFilhos.Items.Add("3");
            lstNumeroFilhos.Items.Add("4");
            lstNumeroFilhos.Items.Add("5");
            lstNumeroFilhos.Items.Add("6");
            lstNumeroFilhos.Items.Add("7");
        }



        private void lblNúmerodeFilhos_Click(object sender, EventArgs e)
        {

        }

        private void mskNomeFuncionário_Validated(object sender, EventArgs e)
        {

        }

        private void mskbxSalárioBruto_Validated(object sender, EventArgs e)
        {
            double salBruto;
            errorProvider1.SetError(mskbxSalárioBruto, "");

            if (!double.TryParse(mskbxSalárioBruto.Text, out salBruto) || (salBruto < 0))
            {
                MessageBox.Show("Valor inválido!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(mskbxSalárioBruto, "Valor inválido!");
            }
        }

        private void btmVerificaDesconto_Click(object sender, EventArgs e)
        {
            double salarioBruto, salarioLiquido, descontoINSS, descontoIRPF, salarioFamilia;
            int numFilhos;

            salarioFamilia = 0;
            numFilhos = 0;
            descontoINSS = 0;
            descontoIRPF = 0;

            if (Double.TryParse(mskbxSalárioBruto.Text, out salarioBruto))
            {
                if (salarioBruto <= 800.47)
                {
                    mskbxAlíquotaInss.Text = "7,65%";
                    descontoINSS = 0.0765 * salarioBruto;
                    salarioLiquido = salarioBruto - descontoINSS;
                    mskbxDescontoInss.Text = descontoINSS.ToString();
                    mskbxSalBruto.Text = salarioLiquido.ToString();
                }
                else if (salarioBruto <= 1050)
                {
                    mskbxAlíquotaInss.Text = "8,65%";
                    descontoINSS = 0.0865 * salarioBruto;
                    salarioLiquido = salarioBruto - descontoINSS;
                    mskbxDescontoInss.Text = descontoINSS.ToString();
                    mskbxSalBruto.Text = salarioLiquido.ToString();
                }
                else if (salarioBruto <= 1400.77)
                {
                    mskbxAlíquotaInss.Text = "9,00%";
                    descontoINSS = 0.09 * salarioBruto;
                    mskbxDescontoInss.Text = descontoINSS.ToString();

                }
                else if (salarioBruto <= 2801.56)
                {
                    mskbxAlíquotaInss.Text = "11,00%";
                    descontoINSS = 0.11 * salarioBruto;
                    mskbxDescontoInss.Text = descontoINSS.ToString();
                }
                else if (salarioBruto > 2801.56)
                {
                    mskbxAlíquotaInss.Text = "teto";
                    descontoINSS = 308.17;
                    mskbxDescontoInss.Text = "308,17";
                }

                if(salarioBruto <= 1257.12)
                {
                    mskbxAlíquotaIrpf.Text = "isento";
                    descontoIRPF = 0;
                    mskbxDescontoIrpf.Text = descontoIRPF.ToString();
                }
                else if(salarioBruto <= 2512.08)
                {
                    mskbxAlíquotaIrpf.Text = "15,00%";
                    descontoIRPF = 0.15 * salarioBruto;
                    mskbxDescontoIrpf.Text = descontoIRPF.ToString();
                }
                else if(salarioBruto > 2512.08)
                {
                    mskbxAlíquotaIrpf.Text = "27,5%";
                    descontoIRPF = 0.275 * salarioBruto;
                    mskbxDescontoIrpf.Text = descontoIRPF.ToString();
                }

                if (salarioBruto <= 435.52)
                {
                    salarioFamilia = 22.33 * numFilhos;
                    mskbxSalárioFamília.Text = salarioFamilia.ToString();
                }
                else if (salarioBruto <= 654.61)
                {
                    salarioFamilia = 15.74 * numFilhos;
                    mskbxSalárioFamília.Text = salarioFamilia.ToString();
                }
                else if (salarioBruto > 654.61)
                {
                    salarioFamilia = 0;
                    mskbxSalárioFamília.Text = salarioFamilia.ToString();
                }

                salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;
                mskbxSalBruto.Text = salarioLiquido.ToString();
            }
        }

        private void lstNumeroFilhos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
