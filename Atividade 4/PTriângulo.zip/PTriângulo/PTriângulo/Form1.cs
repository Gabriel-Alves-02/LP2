﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriângulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            double ladoA;
            errorProvider1.SetError(txtLadoA, "");

            if(!Double.TryParse(txtLadoA.Text, out ladoA) || (ladoA < 0))
            {
                MessageBox.Show("Valor inválido!","Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(txtLadoA, "Valor inválido!");
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            double ladoB;
            errorProvider2.SetError(txtLadoB, "");

            if(!Double.TryParse(txtLadoB.Text, out ladoB) || (ladoB < 0))
            {
                MessageBox.Show("Valor inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider2.SetError(txtLadoB, "Valor inválido!");
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            double ladoC;
            errorProvider3.SetError(txtLadoC, "");

            if(!Double.TryParse(txtLadoC.Text, out ladoC) || (ladoC < 0))
            {
                MessageBox.Show("Valor inválido!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider3.SetError(txtLadoC, "Valor inválido!");
            }
        }

        private void btmAnalisar_Click(object sender, EventArgs e)
        {
            double A, B, C;

            if (Double.TryParse(txtLadoA.Text, out A) && Double.TryParse(txtLadoB.Text, out B) && Double.TryParse(txtLadoC.Text, out C))
            {
                if ((Math.Abs(B - C) < A && A < B + C) && (Math.Abs(A - C) < B && B < A + C) && (Math.Abs(A - B) < C && C < A + B))
                {
                    if ((A == B) && (A == C) && (B == C))
                        MessageBox.Show("É possível formar um triângulo equilátero!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else if ((A == B) || (A == C) || (B == C))
                        MessageBox.Show("É possível formar um triângulo iósceles!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("É possível formar um triângulo escaleno!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Não é possível formar um triângulo!", "Classificação", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
         }

        private void btmLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btmFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
 }

