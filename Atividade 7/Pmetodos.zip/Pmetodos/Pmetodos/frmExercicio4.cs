﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtnContanNumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach(var c in rctxtFrase.Text)
            {
                if (char.IsNumber(c))
                    contador += 1;
            }
            MessageBox.Show("Quantidade de númeross: " + contador);
        }

        private void BtnContaLetra_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i = 0; i < rctxtFrase.Text.Length; i++)
            {
                if (char.IsLetter(rctxtFrase.Text[i]))
                    contador += 1;
            }
            MessageBox.Show($"nº de caracteres: {contador}");
        }

        private void BntPrimeiroCaracter_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contador = 0;
            while(contador < rctxtFrase.Text.Length)
            {
                if(char.IsWhiteSpace(rctxtFrase.Text[contador]))
                {
                    posicao = contador + 1;
                    break;
                }
                contador++;
            }
            MessageBox.Show($"A posição do 1º espaço em branco é: {posicao}");

        }
    }
}
