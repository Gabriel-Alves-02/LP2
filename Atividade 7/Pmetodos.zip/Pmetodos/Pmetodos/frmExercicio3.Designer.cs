﻿namespace Pmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninverter = new System.Windows.Forms.Button();
            this.btnremover2 = new System.Windows.Forms.Button();
            this.btnremover1 = new System.Windows.Forms.Button();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btninverter
            // 
            this.btninverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btninverter.Location = new System.Drawing.Point(420, 176);
            this.btninverter.Name = "btninverter";
            this.btninverter.Size = new System.Drawing.Size(148, 87);
            this.btninverter.TabIndex = 13;
            this.btninverter.Text = "Inverter";
            this.btninverter.UseVisualStyleBackColor = true;
            this.btninverter.Click += new System.EventHandler(this.Btninverter_Click);
            // 
            // btnremover2
            // 
            this.btnremover2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremover2.Location = new System.Drawing.Point(287, 176);
            this.btnremover2.Name = "btnremover2";
            this.btnremover2.Size = new System.Drawing.Size(127, 87);
            this.btnremover2.TabIndex = 12;
            this.btnremover2.Text = "Remover 2";
            this.btnremover2.UseVisualStyleBackColor = true;
            this.btnremover2.Click += new System.EventHandler(this.Btnremover2_Click);
            // 
            // btnremover1
            // 
            this.btnremover1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnremover1.Location = new System.Drawing.Point(130, 176);
            this.btnremover1.Name = "btnremover1";
            this.btnremover1.Size = new System.Drawing.Size(151, 87);
            this.btnremover1.TabIndex = 11;
            this.btnremover1.Text = "Remover 1";
            this.btnremover1.UseVisualStyleBackColor = true;
            this.btnremover1.Click += new System.EventHandler(this.Btnremover1_Click);
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra2.Location = new System.Drawing.Point(126, 107);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(91, 24);
            this.lblpalavra2.TabIndex = 10;
            this.lblpalavra2.Text = "Palavra 2:";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpalavra1.Location = new System.Drawing.Point(126, 56);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(91, 24);
            this.lblpalavra1.TabIndex = 9;
            this.lblpalavra1.Text = "Palavra 1:";
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpalavra2.Location = new System.Drawing.Point(252, 107);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(269, 29);
            this.txtpalavra2.TabIndex = 8;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpalavra1.Location = new System.Drawing.Point(252, 51);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(269, 29);
            this.txtpalavra1.TabIndex = 7;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninverter);
            this.Controls.Add(this.btnremover2);
            this.Controls.Add(this.btnremover1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btninverter;
        private System.Windows.Forms.Button btnremover2;
        private System.Windows.Forms.Button btnremover1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
    }
}