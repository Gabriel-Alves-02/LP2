﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSortear_Click(object sender, EventArgs e)
        {
            int numero1, numero2;
            if(!int.TryParse(txtNumero1.Text, out numero1) || !int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Números inválidos","Erro!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
            {
                if((numero1 <= 0) || (numero2 <= 0) || (numero1 > numero2))
                {
                    MessageBox.Show("O segundo número deve ser maior que o primeiro número","Erro!",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                else
                {
                    Random objRandom = new Random();
                    int aleatorio = objRandom.Next(numero1, numero2);
                    MessageBox.Show("Número aleatório é: " + aleatorio,"Resultado",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
        }
    }
}
