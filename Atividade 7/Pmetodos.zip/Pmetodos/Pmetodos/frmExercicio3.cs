﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void Btnremover1_Click(object sender, EventArgs e)
        {
           /* txtpalavra1.Text = txtpalavra1.ToLower();
            txtpalavra2.Text = txtpalavra2.ToLower(); */


            int posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);

            while(posicao >= 0)
            {
                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) + txtpalavra2.Text.Substring(posicao + txtpalavra1.Text.Length, txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);



                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            }
        }

        private void Btnremover2_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text, "");
        }

        private void Btninverter_Click(object sender, EventArgs e)
        {
            //converte a string para vetor para poder inverter o conteúdo
            char[] vetor = txtpalavra1.Text.ToCharArray();
            //inverte o vetor
            Array.Reverse(vetor);
            //volta o vetor para string
            txtpalavra2.Text = "";
            foreach (char c in vetor)
                txtpalavra2.Text += c;

            //ou
            //txtpalavra2.Text = new string(vetor);
        }
    }
}
