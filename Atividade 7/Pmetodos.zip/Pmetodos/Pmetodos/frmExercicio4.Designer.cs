﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtFrase = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnContanNumero = new System.Windows.Forms.Button();
            this.bntPrimeiroCaracter = new System.Windows.Forms.Button();
            this.btnContaLetra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rctxtFrase
            // 
            this.rctxtFrase.Location = new System.Drawing.Point(204, 66);
            this.rctxtFrase.Name = "rctxtFrase";
            this.rctxtFrase.Size = new System.Drawing.Size(356, 164);
            this.rctxtFrase.TabIndex = 0;
            this.rctxtFrase.Text = "";
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFrase.Location = new System.Drawing.Point(119, 66);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(63, 24);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Frase:";
            // 
            // btnContanNumero
            // 
            this.btnContanNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContanNumero.Location = new System.Drawing.Point(123, 236);
            this.btnContanNumero.Name = "btnContanNumero";
            this.btnContanNumero.Size = new System.Drawing.Size(172, 86);
            this.btnContanNumero.TabIndex = 2;
            this.btnContanNumero.Text = "Conta números";
            this.btnContanNumero.UseVisualStyleBackColor = true;
            this.btnContanNumero.Click += new System.EventHandler(this.BtnContanNumero_Click);
            // 
            // bntPrimeiroCaracter
            // 
            this.bntPrimeiroCaracter.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntPrimeiroCaracter.Location = new System.Drawing.Point(301, 236);
            this.bntPrimeiroCaracter.Name = "bntPrimeiroCaracter";
            this.bntPrimeiroCaracter.Size = new System.Drawing.Size(157, 86);
            this.bntPrimeiroCaracter.TabIndex = 3;
            this.bntPrimeiroCaracter.Text = "Primeiro caracter em branco";
            this.bntPrimeiroCaracter.UseVisualStyleBackColor = true;
            this.bntPrimeiroCaracter.Click += new System.EventHandler(this.BntPrimeiroCaracter_Click);
            // 
            // btnContaLetra
            // 
            this.btnContaLetra.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaLetra.Location = new System.Drawing.Point(464, 236);
            this.btnContaLetra.Name = "btnContaLetra";
            this.btnContaLetra.Size = new System.Drawing.Size(151, 86);
            this.btnContaLetra.TabIndex = 4;
            this.btnContaLetra.Text = "Conta letras";
            this.btnContaLetra.UseVisualStyleBackColor = true;
            this.btnContaLetra.Click += new System.EventHandler(this.BtnContaLetra_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnContaLetra);
            this.Controls.Add(this.bntPrimeiroCaracter);
            this.Controls.Add(this.btnContanNumero);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rctxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtFrase;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnContanNumero;
        private System.Windows.Forms.Button bntPrimeiroCaracter;
        private System.Windows.Forms.Button btnContaLetra;
    }
}