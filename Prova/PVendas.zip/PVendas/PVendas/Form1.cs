﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    //Gabriel Alves Coelho 0030482311011
    //Isabella Pontes 0030482321022
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            double totalMes = 0;
            double totalGeral = 0;
            double[,] vendas = new double[2,4];

            for (var i = 0; i < 2; i++)
            {
                totalMes = 0;
                for (var j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Informe as vendas", "Entrada de dados");
                    if ((!double.TryParse(auxiliar, out vendas[i, j])) || (vendas[i, j] < 0))
                    {
                        MessageBox.Show("Número inválido!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        j--;

                    }
                    else
                    {
                        totalMes += vendas[i, j];
                        lstResultado.Items.Add("Total mes " + (i + 1) + " semana " + (j + 1) + " = " + vendas[i, j].ToString("N2"));
                    }
                }
                lstResultado.Items.Add(">> Total mês: " + totalMes.ToString("C2"));
                lstResultado.Items.Add("----------------------------------------");
                totalGeral += totalMes;
            }
            lstResultado.Items.Add(">> TotalGeral " + totalGeral.ToString("C2"));
        }
    }
}
