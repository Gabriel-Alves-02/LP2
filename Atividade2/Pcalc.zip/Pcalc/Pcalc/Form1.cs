﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
  
    public partial class Calculadora : Form
    {
        double numero1, numero2, resultado;
        public Calculadora()
        {
            InitializeComponent();
        }

        private void Calculadora_Load(object sender, EventArgs e)
        {

        }

        private void TxtNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void BtmSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você realmente deseja sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes);
              Close();
        }

        private void BtmLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();

            txtNumero1.Focus();
            resultado = 0;
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("Número inválido!");
                txtNumero1.Focus();
            }
        }

        private void BtmSubtrair_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtmMultiplicar_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void BtmDividir_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não é possível dividir por zero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero1.Focus();
                txtNumero1.Clear();
                txtNumero2.Clear();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Número inválido!");
                txtNumero2.Focus();
            }
        }

        private void BtmSomar_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();
        }
    }
}
