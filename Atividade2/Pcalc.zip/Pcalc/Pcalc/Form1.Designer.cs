﻿namespace Pcalc
{
    partial class Calculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btmLimpar = new System.Windows.Forms.Button();
            this.btmSair = new System.Windows.Forms.Button();
            this.btmSomar = new System.Windows.Forms.Button();
            this.btmSubtrair = new System.Windows.Forms.Button();
            this.btmMultiplicar = new System.Windows.Forms.Button();
            this.btmDividir = new System.Windows.Forms.Button();
            this.txtNumero1 = new System.Windows.Forms.TextBox();
            this.txtNumero2 = new System.Windows.Forms.TextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblNumero1 = new System.Windows.Forms.Label();
            this.lblNumero2 = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btmLimpar
            // 
            this.btmLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmLimpar.Location = new System.Drawing.Point(290, 29);
            this.btmLimpar.Name = "btmLimpar";
            this.btmLimpar.Size = new System.Drawing.Size(91, 53);
            this.btmLimpar.TabIndex = 6;
            this.btmLimpar.Text = "Limpar";
            this.btmLimpar.UseVisualStyleBackColor = true;
            this.btmLimpar.Click += new System.EventHandler(this.BtmLimpar_Click);
            // 
            // btmSair
            // 
            this.btmSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSair.Location = new System.Drawing.Point(290, 88);
            this.btmSair.Name = "btmSair";
            this.btmSair.Size = new System.Drawing.Size(91, 51);
            this.btmSair.TabIndex = 7;
            this.btmSair.Text = "Sair";
            this.btmSair.UseVisualStyleBackColor = true;
            this.btmSair.Click += new System.EventHandler(this.BtmSair_Click);
            // 
            // btmSomar
            // 
            this.btmSomar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSomar.Location = new System.Drawing.Point(34, 168);
            this.btmSomar.Name = "btmSomar";
            this.btmSomar.Size = new System.Drawing.Size(75, 51);
            this.btmSomar.TabIndex = 2;
            this.btmSomar.Text = "+";
            this.btmSomar.UseVisualStyleBackColor = true;
            this.btmSomar.Click += new System.EventHandler(this.BtmSomar_Click);
            // 
            // btmSubtrair
            // 
            this.btmSubtrair.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmSubtrair.Location = new System.Drawing.Point(125, 168);
            this.btmSubtrair.Name = "btmSubtrair";
            this.btmSubtrair.Size = new System.Drawing.Size(75, 51);
            this.btmSubtrair.TabIndex = 3;
            this.btmSubtrair.Text = "-";
            this.btmSubtrair.UseVisualStyleBackColor = true;
            this.btmSubtrair.Click += new System.EventHandler(this.BtmSubtrair_Click);
            // 
            // btmMultiplicar
            // 
            this.btmMultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmMultiplicar.Location = new System.Drawing.Point(218, 168);
            this.btmMultiplicar.Name = "btmMultiplicar";
            this.btmMultiplicar.Size = new System.Drawing.Size(75, 51);
            this.btmMultiplicar.TabIndex = 4;
            this.btmMultiplicar.Text = "*";
            this.btmMultiplicar.UseVisualStyleBackColor = true;
            this.btmMultiplicar.Click += new System.EventHandler(this.BtmMultiplicar_Click);
            // 
            // btmDividir
            // 
            this.btmDividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btmDividir.Location = new System.Drawing.Point(306, 168);
            this.btmDividir.Name = "btmDividir";
            this.btmDividir.Size = new System.Drawing.Size(75, 51);
            this.btmDividir.TabIndex = 5;
            this.btmDividir.Text = "/";
            this.btmDividir.UseVisualStyleBackColor = true;
            this.btmDividir.Click += new System.EventHandler(this.BtmDividir_Click);
            // 
            // txtNumero1
            // 
            this.txtNumero1.Location = new System.Drawing.Point(125, 29);
            this.txtNumero1.Name = "txtNumero1";
            this.txtNumero1.Size = new System.Drawing.Size(138, 20);
            this.txtNumero1.TabIndex = 0;
            this.txtNumero1.TextChanged += new System.EventHandler(this.TxtNumero1_TextChanged);
            this.txtNumero1.Validated += new System.EventHandler(this.TxtNumero1_Validated);
            // 
            // txtNumero2
            // 
            this.txtNumero2.Location = new System.Drawing.Point(125, 76);
            this.txtNumero2.Name = "txtNumero2";
            this.txtNumero2.Size = new System.Drawing.Size(138, 20);
            this.txtNumero2.TabIndex = 1;
            this.txtNumero2.Validated += new System.EventHandler(this.TxtNumero2_Validated);
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.Location = new System.Drawing.Point(125, 116);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(138, 20);
            this.txtResultado.TabIndex = 8;
            // 
            // lblNumero1
            // 
            this.lblNumero1.AutoSize = true;
            this.lblNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero1.Location = new System.Drawing.Point(31, 29);
            this.lblNumero1.Name = "lblNumero1";
            this.lblNumero1.Size = new System.Drawing.Size(82, 20);
            this.lblNumero1.TabIndex = 9;
            this.lblNumero1.Text = "Número 1:";
            // 
            // lblNumero2
            // 
            this.lblNumero2.AutoSize = true;
            this.lblNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumero2.Location = new System.Drawing.Point(31, 76);
            this.lblNumero2.Name = "lblNumero2";
            this.lblNumero2.Size = new System.Drawing.Size(82, 20);
            this.lblNumero2.TabIndex = 10;
            this.lblNumero2.Text = "Número 2:";
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(31, 116);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(86, 20);
            this.lblResultado.TabIndex = 11;
            this.lblResultado.Text = "Resultado:";
            // 
            // Calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 271);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.lblNumero2);
            this.Controls.Add(this.lblNumero1);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.txtNumero2);
            this.Controls.Add(this.txtNumero1);
            this.Controls.Add(this.btmDividir);
            this.Controls.Add(this.btmMultiplicar);
            this.Controls.Add(this.btmSubtrair);
            this.Controls.Add(this.btmSomar);
            this.Controls.Add(this.btmSair);
            this.Controls.Add(this.btmLimpar);
            this.Name = "Calculadora";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Calculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btmLimpar;
        private System.Windows.Forms.Button btmSair;
        private System.Windows.Forms.Button btmSomar;
        private System.Windows.Forms.Button btmSubtrair;
        private System.Windows.Forms.Button btmMultiplicar;
        private System.Windows.Forms.Button btmDividir;
        private System.Windows.Forms.TextBox txtNumero1;
        private System.Windows.Forms.TextBox txtNumero2;
        private System.Windows.Forms.TextBox txtResultado;
        private System.Windows.Forms.Label lblNumero1;
        private System.Windows.Forms.Label lblNumero2;
        private System.Windows.Forms.Label lblResultado;
    }
}

