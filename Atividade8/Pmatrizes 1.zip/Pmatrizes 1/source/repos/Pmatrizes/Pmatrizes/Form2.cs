﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {



        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            //Dúvida
            string[] nomePessoa = new string[1];
            string[] auxiliar = new string[1] { "" };

            auxiliar = Interaction.InputBox("Informe o nome: ", "Entrada de dados");

            MessageBox.Show("o nome: " + auxiliar + "tem" + auxiliar.Length + "caracteres");
        }
    }
}
