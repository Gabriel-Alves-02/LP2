﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um número", "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);

            /*
            auxiliar = "";

            for(var j = 19; j >= 0; j--)
            {
                auxiliar += vetor[j]+"\n";
            }

            MessageBox.Show(auxiliar);
            */

            //Mostrar usando o reverse

            Array.Reverse(vetor);

            auxiliar = "";

            foreach (var c in vetor)
                auxiliar += c + "\n";

            MessageBox.Show(auxiliar);
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            double[,] vetornotas = new double[20, 3];
            double[] medias = new double[20];
            string stringona = "";
            string auxiliar = "";
            double media = 0;

            for (var j = 0; j < 20; j++)
            {
                media = 0;
            for (var i = 0; i < 3; i++)
            {
                auxiliar = Interaction.InputBox("Informe as notas: ", "Entrada de dados");
                    if (!double.TryParse(auxiliar, out vetornotas[j, i]))
                    {
                        MessageBox.Show("Valor inválido!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--;
                    }
                    else if (vetornotas[j, i] < 0 || vetornotas[j, i] > 10)
                    {
                        MessageBox.Show("Valor inválido!", "Erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        i--;
                    }
                    else
                        media += vetornotas[j, i];
            }
                medias[j] = media / 3;
        }
            for (var a = 0; a < 20; a++)
            {
                stringona = stringona + "A média do aluno "  + (a + 1) + " é: " + medias[a].ToString("N2") + "\n";
            }
            MessageBox.Show(stringona);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            List<string> lista = new List<string>(new string[] {"Ana", "André","Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"});
            lista.Remove("Otávio");

            MessageBox.Show(lista.ToString());
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            Form2 exercicio5 = new Form2();
            exercicio5.ShowDialog();
        }

        private void exercício5ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "José", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for(I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }
    }
    
}
